const modal = document.getElementById('modalLogout');
const openBtn = document.getElementById('btnOpenLogout');
const closeBtn = document.getElementById('confirmNo');

// Abrir modal al hacer clic en Cerrar Sesión
openBtn.onclick = () => {
    modal.style.display = 'flex';
};

// Cerrar modal al dar en Cancelar
closeBtn.onclick = () => {
    modal.style.display = 'none';
};

// Cerrar si hacen clic fuera del cuadro blanco
window.onclick = (e) => {
    if (e.target == modal) modal.style.display = 'none';
};